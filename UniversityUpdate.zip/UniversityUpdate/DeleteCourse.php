<?php
$servername = "localhost";
$username = "root";
$password = "csc";
$dbname = "University";
$course=$_POST["course"];
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// sql to delete a record
$sql = "DELETE FROM course WHERE Course_number='".$course."'";

if (mysqli_query($conn, $sql)) {
    echo "<center>Record deleted successfully<center>";
    echo "<br><center><a href=\"index.html\" style=\"text-decoration:none\"><button>Goto Home</a></button></center>";
    echo "<br><center><footer class=\"footer\"><h3>Developed by Saiteja Enimidigandla - 999902573</h3></footer></center>";
} else {
    echo "Error deleting record: " . mysqli_error($conn);
    echo "<br><a href=\"index.html\" style=\"text-decoration:none\"><button>Goto Home</a></button></center>";
    echo "<br><center><footer class=\"footer\"><h3>Developed by Saiteja Enimidigandla - 999902573</h3></footer></center>";
    
}

mysqli_close($conn);
?>

