<?php
$servername = "localhost";
$username = "root";
$password = "csc";
$dbname = "University";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$course_name=$_POST["courseName"];
$code=$_POST["courseCode"];
$credits=$_POST["CreditHours"];
$ins=$_POST["Instructor"];
$sql = "INSERT INTO course
VALUES ('$course_name', '$code', '$credits','$ins')";

if (mysqli_query($conn, $sql)) {
    echo "<center><h3>New record created successfully</h3><center><br>";
    echo "<br><center><a href=\"index.html\" style=\"text-decoration:none\"><button>Goto Home</a></button></center>";
    echo "<br><center><footer class=\"footer\"><h3>Developed by Saiteja Enimidigandla - 999902573</h3></footer></center>";
    
} else {
    echo "<br><center>Error: " . $sql . "<br>" . mysqli_error($conn);
    echo "<br><a href=\"index.html\" style=\"text-decoration:none\"><button>Goto Home</a></button></center>";
    echo "<br><center><footer class=\"footer\"><h3>Developed by Saiteja Enimidigandla - 999902573</h3></footer></center>";
    
}

mysqli_close($conn);
?>

