<?php
require_once ('./mysqli_connect.php');
$ins=$_POST['ins'];



$sql="SELECT *
FROM course
JOIN section
ON course.Course_number = section.Course_number
WHERE Section.Instructor = '".$ins."'";

$result = mysqli_query($dbc,$sql);
echo "<center><h4>Instructor Courses</h4></center>";
echo "<center><table border='1' >
<tr>
<th>Course Name</th>
<th>Section Number</th>
<th>Instructor Name</th>
<th>Semester</th>
<th>year</th>
<th>Department</th>

</tr>";

while($row = mysqli_fetch_array($result))
{
	echo "<tr>";
	echo "<td>" . $row['Course_name'] . "</td>";
	echo "<td>" . $row['Section_identifier'] . "</td>";
	echo "<td>" . $row['Instructor'] . "</td>";
	echo "<td>" . $row['Semester'] . "</td>";
	echo "<td>" . $row['Year'] . "</td>";
	echo "<td>" . $row['Department'] . "</td>";

	echo "</tr>";
}
echo "</table></center>";
echo "<br><center><a href=\"index.html\" style=\"text-decoration:none\"><button>Goto Home</a></button></center>";
echo "<center><footer class=\"footer\"><h3>Developed by Saiteja Enimidigandla - 999902573</h3></footer></center>";
mysqli_close($dbc);
?>