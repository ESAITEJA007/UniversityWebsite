<?php
require_once ('./mysqli_connect.php');
$dept=$_POST['dept'];

$sql="SELECT * from course where department='".$dept."'";

$result = mysqli_query($dbc,$sql);

echo "<center><table border='1' >
<tr>
<th>Course Name</th>
<th>Course Code</th>
<th>Department</th>


</tr>";

while($row = mysqli_fetch_array($result))
{
	echo "<tr>";
	echo "<td>" . $row['Course_name'] . "</td>";
	echo "<td>" . $row['Course_number'] . "</td>";
	echo "<td>" . $row['Department'] . "</td>";
	

	echo "</tr>";
}
echo "</table></center>";
echo "<br><center><a href=\"index.html\" style=\"text-decoration:none\"><button>Goto Home</a></button></center>";
echo "<center><footer class=\"footer\"><h3>Developed by Saiteja Enimidigandla - 999902573</h3></footer></center>";
mysqli_close($dbc);
?>