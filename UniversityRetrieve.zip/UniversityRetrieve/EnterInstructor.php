<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Instructor</title>
	<style type="text/css" title="text/css" media="all">
	label {
		font-weight: bold;
		color: #300ACC;
	}
	</style>
</head>
<body>
<form action="InstructorsInfo.php" method="post"><br>
<center><h4><b>Select Instructor</b></h4></center><br>
<?php
require_once ('./mysqli_connect.php');

$sql="SELECT distinct(Instructor)FROM section";


$result = mysqli_query($dbc,$sql);


echo "<center><Select name='ins' >";


while($row = mysqli_fetch_array($result))
{
    $val= $row['Instructor'];
	echo "<option ";
	
	echo "value=\"" . $val . "\">".$row['Instructor'] ;
	echo "</option>";
}
echo "</Select></center>";


mysqli_close($dbc);
?>

	
<center><input type="submit" name="submit" value="Go" /></center><br>
<center><a href="index.html" style="text-decoration:none"><button>Goto Home</a></button></center>

</form><center>
<footer class="footer"><h3>Developed by Saiteja Enimidigandla - 999902573</h3></footer></center>
</body>
</html>